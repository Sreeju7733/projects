<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{get3metatagupdater}prestashop>get3metatagupdater_bdbae94b2fa2650c535e7668a6577cf5'] = 'Aktualizacja Meta dla Produktów';
$_MODULE['<{get3metatagupdater}prestashop>get3metatagupdater_880d70e1ffe1632c7d62d91a2596dfbe'] = 'Aktualizacja meta tagów produktu. Jeśli tagi nie istnieją, moduł wygeneruje tagi z tytułu i opisu.';
$_MODULE['<{get3metatagupdater}prestashop>configure_1e9f0ef8ec5e8a42d6072abd7fee5767'] = 'Dane zostały pomyślnie zaktualizowane';
$_MODULE['<{get3metatagupdater}prestashop>configure_96ab50a9c60d09f5e3c71a6950ecb521'] = 'Aktualizacja meta w produktach';
$_MODULE['<{get3metatagupdater}prestashop>configure_d7940c33612cf867143d94f0a82978f7'] = 'Ilość produktów:';
$_MODULE['<{get3metatagupdater}prestashop>configure_40f8d6d374081ac8d19a124d9248deca'] = 'Bez tytułu meta:';
$_MODULE['<{get3metatagupdater}prestashop>configure_353cd3837ca013ba24bd933c8b1c54d8'] = 'Bez opisu meta:';
$_MODULE['<{get3metatagupdater}prestashop>configure_18c8293513db51637a1539b72b6c9574'] = 'Sprawdzanie i aktualizacja produktów:';
$_MODULE['<{get3metatagupdater}prestashop>configure_8665c40583b2098edbab6f38ae0a9395'] = 'Pamiętaj, aby utworzyć kopię zapasową przed utworzeniem meta. Moduł nie nadpisze istniejących danych, a jedynie uzupełni puste metadane.';
$_MODULE['<{get3metatagupdater}prestashop>configure_4c61e2088402a7c73eff515ab590d3cd'] = 'Moduł automatycznie przypisze tytuł meta i opis meta do produktów, jeśli nie mają one opisu i nazwy produktu.';
$_MODULE['<{get3metatagupdater}prestashop>configure_a8ec7f863474af3eb9435643a41f0dd3'] = 'Aktualizuj meta';
$_MODULE['<{get3metatagupdater}prestashop>configure_15d2a59d70893065afa3bd8d90591d54'] = 'Profesjonalne strony internetowe i sklepy internetowe. Wsparcie techniczne dla PrestaShop.';
$_MODULE['<{get3metatagupdater}prestashop>configure_1506e0eae1a1f99520450fbcda0db81b'] = 'Moduł rozwijamy za darmo - możesz nas wesprzeć darowizną.';
$_MODULE['<{get3metatagupdater}prestashop>configure_0584e445d656b83b431227bb80ff0c30'] = 'Darowizna';
