<?php
require_once('../../config/config.inc.php');
require_once('../../init.php');

$secure_token = Configuration::get('G3TOKEN_TXTPASS');

if($secure_token === $_POST['secure']) {

    if(isset($_POST['work']) && $_POST['work'] == 'lang') {

        $products = ProductCore::getProducts((int)$_POST['lang'], null, null, 'id_product', 'ASC');
        $countLang = 0;
        $countMeta = 0;
        $countDesc = 0;

        foreach($products as $product) {
            $productOT = new Product($product['id_product'], false, (int)$_POST['lang']);
            $countLang++;

            $meta_title = trim($productOT->meta_title);
            $meta_desc = trim($productOT->meta_description);

            if(empty($meta_title) || strlen($meta_title) < 5) {
                $countMeta++;
            }
            if(empty($meta_desc) || strlen($meta_desc) < 5) {
                $countDesc++;
            }
        }

        $dataWork = array('all' => $countLang, 'meta' => $countMeta, 'desc' =>$countDesc);
        echo json_encode($dataWork);
        
    } else {

        $obModule = Module::getInstanceByName('get3metatagupdater');
        $limit = 100;
        $starter = 0;

        if(!isset($_POST['next']) || $_POST['next'] == 0) {
            $offset = 0;
        } else {
            $offset = (int)$_POST['next'];
        }

        $products = ProductCore::getProducts(Context::getContext()->language->id, $offset, $limit, 'id_product', 'ASC');
        $languages = Language::getLanguages(false);
        $prods = [];

        foreach ($products as $product) {
            foreach ($languages as $lang) {
                $id_lang = $lang['id_lang'];

                $productOT = new Product($product['id_product'], false, $id_lang);

                $meta_title = trim($productOT->meta_title);
                $meta_desc = trim($productOT->meta_description);

                if(empty($meta_title) || strlen($meta_title) < 5) {
                    $obModule->updateMetaTags((int)$product['id_product'], 'title', $id_lang);
                }
                if(empty($meta_desc) || strlen($meta_desc) < 5) {
                    $obModule->updateMetaTags((int)$product['id_product'], 'description', $id_lang);
                }
                $prods[] = $product['id_product'];
                $starter++;
            }
        }
        if(!isset($_POST['next'])) {
            $_POST['next'] = 0;
        }

        $data = array('count' => (int)$_POST['count'] - $limit, 'offset' => ((int)$_POST['next'] + $starter), 'prods' => $prods);
        echo json_encode($data);
    }
} else {
    die();
}
