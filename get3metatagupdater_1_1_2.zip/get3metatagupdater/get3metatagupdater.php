<?php
/**
* 2007-2023 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    Daniel Borawski <daniel@ger3code.com>
*  @copyright 2023 get3code.com
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
if (!defined('_PS_VERSION_')) {
    exit;
}

class Get3metatagupdater extends Module
{
    protected $config_form = false;
    public function __construct()
    {
        $this->name = 'get3metatagupdater';
        $this->tab = 'administration';
        $this->version = '1.1.2';
        $this->author = 'get3code.com';
        $this->need_instance = 0;
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('Product meta tag updater');
        $this->description = $this->l('Product meta tag update. If the tags do not exist, the module will generate tags from the title and description.');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        Configuration::updateValue('G3TOKEN_TXTPASS', hash('sha256', 'get3_' . $_SERVER['HTTP_HOST'] . time()));
        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('displayBackOfficeHeader');
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    public function getContent()
    {   
        $productNoTitle = 0;
        $productNoDesc = 0;
        $confMsg = '';
        $languages = Language::getLanguages(false);
        $allProducts = Product::getProducts($languages[0]['id_lang'], 0, 0, 'id_product', 'ASC');

        foreach ($allProducts as $product) {
            $meta_title = trim($product['meta_title']);
            $meta_desc = trim($product['meta_description']);
            if (empty($meta_title)) {
                $productNoTitle++;
            }
            if (empty($meta_desc)) {
                $productNoDesc++;
            }
        }
        
        $urlModule = _PS_BASE_URL_.__PS_BASE_URI__.'modules/get3metatagupdater/';
        $this->context->smarty->assign('module_dir', $this->_path);
        $this->context->smarty->assign('get3img', $urlModule.'views/img/get3code.webp');
        $this->context->smarty->assign('get3seo', $urlModule.'views/img/seotools.jpg');
        $this->context->smarty->assign('all', count($allProducts));
        $this->context->smarty->assign('languages', $languages);
        $this->context->smarty->assign('secure', Configuration::get('G3TOKEN_TXTPASS'));
        $this->context->smarty->assign('no_meta_title', $productNoTitle);
        $this->context->smarty->assign('no_meta_desc', $productNoDesc);
        $this->context->smarty->assign('confirmations', $confMsg);
        $this->context->smarty->assign('test', Configuration::get('DBTEST'));
        $output = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');
        return $output;
    }

    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');
        }
        Media::addJsDef(array(
            'get3updaterMeta' => $this->_path.'updater.php'
        ));
    }

    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
    }

    public function updateMetaTitles()
    {
        $id_lang = Context::getContext()->language->id;
        $sql = 'UPDATE '._DB_PREFIX_.'product_lang
                SET meta_title = LEFT(name, 120)
                WHERE id_lang = '.(int)$id_lang;
        Db::getInstance()->execute($sql);
    }

    public function hookUpdateMetaTags($id, $meta)
    {
       //Move to ajax method
    }

    public function updateMetaTags($id, $meta, $id_lang) {
        $product = new Product((int)$id, false, $id_lang);
        if($meta == 'title') {
            $title = $product->name;
            $newTitle = substr($title,0,120);
            $sqlTitle = 'UPDATE '._DB_PREFIX_.'product_lang SET meta_title = "'.pSQL($newTitle).'" WHERE id_product = '.(int)$id.' AND id_lang = '.$id_lang;
            Db::getInstance()->execute($sqlTitle);
        }
        if ($meta == 'description') {
            $description = $product->description;
            if (empty($description) || $description == '' || strlen($description) < 10) {
                $description = $product->name;
            }
            $desc = trim(strip_tags($description));
            $newDescTemp = substr($desc, 0, 160);
            $newDesc = !empty($newDescTemp) ? preg_replace('/[^\p{L}\p{N}\s]/u', '', $newDescTemp) : $desc;
            $sqlDesc = 'UPDATE '._DB_PREFIX_.'product_lang SET meta_description = "'.pSQL(mb_convert_encoding($newDescTemp,'UTF-8', 'auto')).'" WHERE id_product = '.(int)$product->id.' AND id_lang = '.$id_lang;
            Db::getInstance()->execute($sqlDesc);
        }
    }
}
